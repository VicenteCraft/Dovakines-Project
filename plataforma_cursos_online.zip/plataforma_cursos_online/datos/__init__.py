from datos.auxiliar import nombre_app,version_app,main_menu
